--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;

ALTER TABLE ONLY public.tbl_movimiestos_caja_chica DROP CONSTRAINT tbl_movimiestos_caja_chica_tipo_movimiento_fkey;
ALTER TABLE ONLY public.tbl_tipo_movimientos DROP CONSTRAINT tbl_tipo_movimientos_pkey;
ALTER TABLE ONLY public.tbl_tipo_movimientos DROP CONSTRAINT tbl_tipo_movimientos_nombre_key;
ALTER TABLE ONLY public.tbl_movimiestos_caja_chica DROP CONSTRAINT tbl_movimiestos_caja_chica_pkey;
ALTER TABLE ONLY public.tbl_caja_chica DROP CONSTRAINT tbl_caja_chica_pkey;
ALTER TABLE ONLY public.tbl_productos DROP CONSTRAINT primerkey_tblproducto;
ALTER TABLE ONLY public.tbl_finanzas DROP CONSTRAINT primarykey_tblfinanzas;
ALTER TABLE ONLY public.tbl_finanzashist DROP CONSTRAINT "primarykey_tbl_finanzasHist";
ALTER TABLE ONLY public.tbl_inventario DROP CONSTRAINT primarykey_idinventario;
ALTER TABLE ONLY public.tbl_materiaprima DROP CONSTRAINT "primarykey_idMateriaPrima";
ALTER TABLE ONLY public.tbl_recetario DROP CONSTRAINT pkey_tblrecetario;
ALTER TABLE ONLY public.tbl_pedidos DROP CONSTRAINT pkey;
ALTER TABLE ONLY public.tbl_estatuspedidos DROP CONSTRAINT pk_idestatuspedido;
ALTER TABLE ONLY public.tbl_compras DROP CONSTRAINT id_compra_primarykey;
ALTER TABLE ONLY public.tbl_egresosfijos DROP CONSTRAINT egresofijo_pk;
ALTER TABLE public.tbl_tipo_movimientos ALTER COLUMN id_movimiento DROP DEFAULT;
ALTER TABLE public.tbl_recetario ALTER COLUMN id_receta DROP DEFAULT;
ALTER TABLE public.tbl_productos ALTER COLUMN id_producto DROP DEFAULT;
ALTER TABLE public.tbl_pedidos ALTER COLUMN id_pedidos DROP DEFAULT;
ALTER TABLE public.tbl_materiaprima ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tbl_inventario ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tbl_finanzashist ALTER COLUMN id_finanzahist DROP DEFAULT;
ALTER TABLE public.tbl_finanzas ALTER COLUMN id_finanzas DROP DEFAULT;
ALTER TABLE public.tbl_estatuspedidos ALTER COLUMN id_estatuspedido DROP DEFAULT;
ALTER TABLE public.tbl_egresosfijos ALTER COLUMN id_egresofijo DROP DEFAULT;
ALTER TABLE public.tbl_compras ALTER COLUMN id_compra DROP DEFAULT;
DROP SEQUENCE public.tbl_tipo_movimientos_id_movimiento_seq;
DROP TABLE public.tbl_tipo_movimientos;
DROP SEQUENCE public.tbl_recetario_id_receta_seq;
DROP TABLE public.tbl_recetario;
DROP SEQUENCE public.tbl_productos_id_producto_seq;
DROP TABLE public.tbl_productos;
DROP SEQUENCE public.tbl_pedidos_id_pedidos_seq;
DROP TABLE public.tbl_pedidos;
DROP TABLE public.tbl_movimiestos_caja_chica;
DROP SEQUENCE public.tbl_materiaprima_id_seq;
DROP TABLE public.tbl_materiaprima;
DROP SEQUENCE public.tbl_inventario_id_seq;
DROP TABLE public.tbl_inventario;
DROP SEQUENCE public.tbl_finanzashist_id_finanzahist_seq;
DROP TABLE public.tbl_finanzashist;
DROP SEQUENCE public.tbl_finanzas_id_finanzas_seq;
DROP TABLE public.tbl_finanzas;
DROP SEQUENCE public.tbl_estatuspedidos_id_estatuspedido_seq;
DROP TABLE public.tbl_estatuspedidos;
DROP SEQUENCE public.tbl_egresosfijos_id_egresofijo_seq;
DROP TABLE public.tbl_egresosfijos;
DROP SEQUENCE public.tbl_compras_id_compra_seq;
DROP TABLE public.tbl_compras;
DROP TABLE public.tbl_caja_chica;
DROP SEQUENCE public.movimiestos_caja_chica_id_seq;
DROP SEQUENCE public.caja_chica_id_seq;
DROP FUNCTION public.sp_total_caja_chica();
DROP FUNCTION public.sp_receta(idproduct integer);
DROP FUNCTION public.sp_nuevoproductoduplicado(product character varying, prec double precision, cantidadtanda double precision);
DROP FUNCTION public.sp_nuevoproducto(product character varying, prec double precision, cantidadtanda double precision);
DROP FUNCTION public.sp_nuevopedido(producto integer, precio double precision, cantidad double precision, costo double precision, pago character varying, client character varying);
DROP FUNCTION public.sp_nuevopago(idpedido integer, nuevopago double precision, deuda double precision);
DROP FUNCTION public.sp_nuevomodifgastomp(materiap integer, fechacompra date, cant double precision, precionuevo double precision, pesomp double precision, numcompra integer, idcompra integer);
DROP FUNCTION public.sp_nuevogastomp(materiap integer, fechacompra date, cant double precision, precio double precision, pesomp double precision, numcompra integer);
DROP FUNCTION public.sp_nuevogastoef(egresofijo integer, fechacompra date, gasto double precision);
DROP FUNCTION public.sp_nuevoegresofijo(ef character varying, gasto double precision);
DROP FUNCTION public.sp_nuevoarticulo(materiap character varying);
DROP FUNCTION public.sp_nuevareceta(idproduct integer, idmp integer, cant double precision, indexx integer);
DROP FUNCTION public.sp_movimientos_caja_chica();
DROP FUNCTION public.sp_modifpedido(producto integer, precio double precision, cant double precision, costo double precision, pago character varying, client character varying, idpedido integer);
DROP FUNCTION public.sp_modificaregresofijo(ef character varying, gasto double precision, id character varying);
DROP FUNCTION public.sp_modificararticulo(materiap character varying, idmp integer);
DROP FUNCTION public.sp_modifgastoef(egresofijo integer, fechacompra date, precionuevo double precision, idcompra integer);
DROP FUNCTION public.sp_listampprecio();
DROP FUNCTION public.sp_listamp();
DROP FUNCTION public.sp_guardarcajachica(monto double precision);
DROP FUNCTION public.sp_eliminarpedido(idpedido integer);
DROP FUNCTION public.sp_eliminararticulo(idmp integer);
DROP FUNCTION public.sp_egresocajachica(egreso double precision);
DROP FUNCTION public.sp_duplicarreceta(idproduct integer, idmp integer, cant double precision);
DROP FUNCTION public.sp_consultarecetas();
DROP FUNCTION public.sp_consultareceta(id_product integer);
DROP FUNCTION public.sp_consultaproductosventas();
DROP FUNCTION public.sp_consultaproductos();
DROP FUNCTION public.sp_consultaproducto(idproducto integer);
DROP FUNCTION public.sp_consultapedidos(stats integer);
DROP FUNCTION public.sp_consultanumpedidos();
DROP FUNCTION public.sp_consultamp();
DROP FUNCTION public.sp_consultahistfinanza();
DROP FUNCTION public.sp_consultagastos();
DROP FUNCTION public.sp_consultagastomodif(idcompra integer);
DROP FUNCTION public.sp_consultafinanza();
DROP FUNCTION public.sp_consultaegresosfijos();
DROP FUNCTION public.sp_cambioestatuspedido(status integer, idpedido integer);
DROP FUNCTION public.sp_cambiarnombrereceta(newname character varying, idproducto integer, cantidadtanda double precision);
DROP FUNCTION public.sp_cambiarganancia(monto double precision, id integer);
DROP FUNCTION public.sp_busquedapedido(id integer);
DROP FUNCTION public.sp_borrarreceta(idproduct integer);
DROP FUNCTION public.sp_aggcapital(monto double precision);
DROP FUNCTION public.sp_actualizarmp(materiap integer, cantidadmp double precision, accioncant character varying);
DROP FUNCTION public.sp_actpreciocosto(idproduct integer);
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: sp_actpreciocosto(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_actpreciocosto(idproduct integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$

	DECLARE 
		preciomp double precision;
		r record;
         	begin
			update tbl_productos
			set precio_und = 0
			where id_producto = idproduct;

			FOR r IN select * from  tbl_recetario where id_producto=idproduct
			LOOP
			preciomp:=(select precio_materiaprima from  tbl_materiaprima where id=r.id_materiaprima);
			update tbl_productos
			set precio_und = precio_und + (r.cantidad * preciomp)
			where id_producto = idproduct;
			--RETURN NEXT r; 
			END LOOP;


		return 1;

--select * from  sp_ActPrecioCosto(6)
--select * from  tbl_productos where 
-- 
-- select * from  tbl_recetario where id_producto = 6 limit 1 offset 1
-- select count(*) from  tbl_recetario where id_producto = 3
-- select * from tbl_materiaprima where id = 8 
-- 		


End;

$$;


ALTER FUNCTION public.sp_actpreciocosto(idproduct integer) OWNER TO postgres;

--
-- Name: sp_actualizarmp(integer, double precision, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_actualizarmp(materiap integer, cantidadmp double precision, accioncant character varying) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
	
	DECLARE consultaMP integer;
	DECLARE cant_stock_MP double precision;
         	begin
		consultaMP:= (select count(*) from tbl_inventario where id_materiaprima = materiap); --Validando si existe en stock
		-- consultaMP = 0 no existe en stock
		if consultaMP = 0 or consultaMP is null then 
		INSERT INTO tbl_inventario(cant_stock, id_materiaprima)
		VALUES (cantidadmp, materiap);
		return 1;
		else -- si existe
		--buscando cantidad en stock del producto
		cant_stock_MP:= (select cant_stock from tbl_inventario where id_materiaprima = materiap);
		--validando si se agrega a stock o se resta
		--case when accionCant = 'rest' then   
		if accionCant = 'res' then cantidadmp =  cant_stock_MP - cantidadmp; else  cantidadmp = cant_stock_MP + cantidadmp; end if;
		if cantidadmp < 0 then return 0; else
		UPDATE tbl_inventario
		SET  cant_stock=cantidadmp
		WHERE id_materiaprima=materiap;
		return 1;
		--select * from sp_actualizarMP(8,1,'res')
		--select * from tbl_inventario
		end if;
		
		end if;
		
		

		


End;

$$;


ALTER FUNCTION public.sp_actualizarmp(materiap integer, cantidadmp double precision, accioncant character varying) OWNER TO postgres;

--
-- Name: sp_aggcapital(double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_aggcapital(monto double precision) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
	
         	begin
		UPDATE tbl_finanzas
		   SET capital=(capital + monto)
		 WHERE id_finanzas=1;

		return 1;


End;

$$;


ALTER FUNCTION public.sp_aggcapital(monto double precision) OWNER TO postgres;

--
-- Name: sp_borrarreceta(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_borrarreceta(idproduct integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$

	DECLARE existe integer;
         	begin
		
		existe:= (select count(*) from tbl_recetario where id_producto=idproduct); --Validando si existe el nuevo producto
		if existe = 0 then -- si no existe, insert
			return 0;
		else 
			delete from tbl_recetario where id_producto=idproduct;
			return 1;
		end if;
--select * from  sp_nuevaReceta(3,12,100,2)
		--select * from tbl_recetario where id_producto=3 


End;

$$;


ALTER FUNCTION public.sp_borrarreceta(idproduct integer) OWNER TO postgres;

--
-- Name: sp_busquedapedido(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_busquedapedido(id integer) RETURNS TABLE(id_pedidos integer, descr character varying, precio_und numeric, total numeric, fecha date, estatus text, cantidad double precision, cliente character varying, usuario character varying, monto double precision, id_product integer)
    LANGUAGE plpgsql
    AS $$
	
	Begin

         return 	QUERY  
				
				SELECT e.id_pedidos, p.descrip, round(e.precio_und::numeric,2),round(e.total::numeric,2), e.fecha, case when e.estatus = 1 then 'PENDIENTE' when 
				e.estatus = 2 then 'PROCESO' else 'COBRANZA' end as status,
				e.cantidad, e.cliente, e.usuario, case when fi.montos is null then 0 else  fi.montos end, e.id_producto
				FROM tbl_pedidos e 
				inner join tbl_productos p on p.id_producto = e.id_producto
				left join (select f.id_pedido, sum(f.monto) as montos from tbl_finanzashist f GROUP BY id_pedido) fi on fi.id_pedido = e.id_pedidos
				where e.id_pedidos= id;
				
				
	End;
--select * from tbl_recetario
--select * from tbl_materiaprima
--select * from tbl_productos
--select * from sp_busquedaPedido(11)
$$;


ALTER FUNCTION public.sp_busquedapedido(id integer) OWNER TO postgres;

--
-- Name: sp_cambiarganancia(double precision, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_cambiarganancia(monto double precision, id integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
         	begin
		
		UPDATE tbl_productos
		SET  ganancia=monto
		WHERE id_producto=id;
		return 1;
		
--select * from  sp_nuevoarticulo('HARINA')
		


End;

$$;


ALTER FUNCTION public.sp_cambiarganancia(monto double precision, id integer) OWNER TO postgres;

--
-- Name: sp_cambiarnombrereceta(character varying, integer, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_cambiarnombrereceta(newname character varying, idproducto integer, cantidadtanda double precision) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
	
	
         	begin
		UPDATE tbl_productos
		   SET  descrip=newName, ctanda=cantidadtanda
		 WHERE id_producto=idproducto;

		return 1;

End;

$$;


ALTER FUNCTION public.sp_cambiarnombrereceta(newname character varying, idproducto integer, cantidadtanda double precision) OWNER TO postgres;

--
-- Name: sp_cambioestatuspedido(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_cambioestatuspedido(status integer, idpedido integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$

         	begin
		UPDATE tbl_pedidos
		   SET  estatus=status
		 WHERE id_pedidos=idpedido;

		return 1;
--select * from  sp_cambioEstatusPedido(1,)
--select * from  tbl_pedidos
		


End;

$$;


ALTER FUNCTION public.sp_cambioestatuspedido(status integer, idpedido integer) OWNER TO postgres;

--
-- Name: sp_consultaegresosfijos(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_consultaegresosfijos() RETURNS TABLE(id_egresofijo integer, egresofijo character varying, costo double precision, fecha date, usuario character varying)
    LANGUAGE plpgsql
    AS $$
	
	Begin

         return 	QUERY  
				
				select * from tbl_egresosfijos;
				

				
				
	End;
--select * from tbl_recetario
--select * from tbl_materiaprima
--select * from tbl_productos
--select * from  sp_consultaGastos()
--select * from  tbl_inventario
$$;


ALTER FUNCTION public.sp_consultaegresosfijos() OWNER TO postgres;

--
-- Name: sp_consultafinanza(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_consultafinanza() RETURNS TABLE(id_finanzas integer, capital double precision)
    LANGUAGE plpgsql
    AS $$
	
	Begin

         return 	QUERY  
				
			select * from tbl_finanzas;
				
	End;
--select * from tbl_recetario
--select * from tbl_materiaprima
--select * from sp_consultahistfinanza()
$$;


ALTER FUNCTION public.sp_consultafinanza() OWNER TO postgres;

--
-- Name: sp_consultagastomodif(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_consultagastomodif(idcompra integer) RETURNS TABLE(id_compra integer, gasto character varying, nro_compra character varying, fecha_compra date, cantidad_mp double precision, peso double precision, precio double precision, idgasto integer)
    LANGUAGE plpgsql
    AS $$
	
	Begin

         return 	QUERY  
				
				select c.id_compra, (case when c.id_materiaprima is null then e.egresofijo else i.materiaprima end) as gasto, 
				c.nro_compra, c.fecha_compra, c.cantidad_mp, c.peso, c.precio,
				(case when c.id_materiaprima is null then c.id_egresofijo else c.id_materiaprima end) as idgasto
				from tbl_compras c
				left join tbl_materiaprima i on c.id_materiaprima = i.id
				left join tbl_egresosfijos e on c.id_egresofijo = e.id_egresofijo
				where  c.id_compra = idCompra
				order by fecha_compra desc;	

				
			-- 8 - 55	finanzas - 560
	End;
--select * from tbl_recetario
--select * from tbl_materiaprima
--select * from tbl_finanzas
--select * from tbl_inventario
--select * from  sp_consultagastomodif()
$$;


ALTER FUNCTION public.sp_consultagastomodif(idcompra integer) OWNER TO postgres;

--
-- Name: sp_consultagastos(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_consultagastos() RETURNS TABLE(id_compra integer, gasto character varying, nro_compra character varying, fecha_compra date, cantidad_mp double precision, peso double precision, precio double precision, tipogasto text)
    LANGUAGE plpgsql
    AS $$
	
	Begin

         return 	QUERY  
				
				select c.id_compra, (case when c.id_materiaprima is null then egresofijo else i.materiaprima end) as gasto, 
				c.nro_compra, c.fecha_compra, c.cantidad_mp, c.peso, c.precio,
				(case when c.id_materiaprima is null then 'Egreso Fijo' else 'Materia Prima' end) as tipogasto
				from tbl_compras c
				left join tbl_materiaprima i on c.id_materiaprima = i.id
				left join tbl_egresosfijos e on c.id_egresofijo = e.id_egresofijo
				order by fecha_compra desc;	

				
				
	End;
--select * from tbl_compras
--select * from tbl_materiaprima
--select * from tbl_productos
--select * from  sp_consultaGastos()
--select * from  tbl_inventario
--select * from  tbl_egresosfijos
$$;


ALTER FUNCTION public.sp_consultagastos() OWNER TO postgres;

--
-- Name: sp_consultahistfinanza(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_consultahistfinanza() RETURNS TABLE(id_finanzahist integer, monto double precision, tipo text, concepto character varying, fecha date, usuario character varying, id_pedido integer, id_compra integer, descripcion text)
    LANGUAGE plpgsql
    AS $$
	
	Begin

         return 	QUERY  
				
			select hf.id_finanzahist, case when hf.id_compra is not null then(hf.monto * c.cantidad_mp) else hf.monto end, case when hf.tipo_tx = 1 then 'Ingreso' else 'Egreso' end as tipo, hf.concepto, 
			hf.fecha, hf.usuario, hf.id_pedido, hf.id_compra, case when hf.id_compra is null and hf.id_pedido is null then hf.concepto when hf.id_compra is null then concat_ws('', 'Pago pedido ', pr.descrip,' del cliente ',p.cliente) 
			else case when id_materiaprima is null then concat_ws('', 'Gasto ', ef.egresofijo) 
			 else  concat_ws('', 'Compra de ', mp.materiaprima)   end end as descripcion  from tbl_finanzashist hf
			left join tbl_pedidos p on p.id_pedidos = hf.id_pedido
			left join tbl_productos pr on p.id_producto = pr.id_producto
			left join tbl_compras c on c.id_compra = hf.id_compra
			left join tbl_materiaprima mp on mp.id = c.id_materiaprima
			left join tbl_egresosfijos ef on ef.id_egresofijo = c.id_egresofijo
			where hf.monto > 0;
				
	End;
--select * from tbl_recetario
--select * from tbl_materiaprima
--select * from sp_consultahistfinanza()
$$;


ALTER FUNCTION public.sp_consultahistfinanza() OWNER TO postgres;

--
-- Name: sp_consultamp(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_consultamp() RETURNS TABLE(id_mp integer, descp character varying, cant double precision)
    LANGUAGE plpgsql
    AS $$
	
	Begin

         return 	QUERY   SELECT e.id, e.materiaprima, case when i.cant_stock is null then 0 else i.cant_stock end
				FROM tbl_materiaprima e
				left join tbl_inventario i on i.id_materiaprima =  e.id;
	End;
--select * from tbl_inventario
--select * from sp_consultamp()
$$;


ALTER FUNCTION public.sp_consultamp() OWNER TO postgres;

--
-- Name: sp_consultanumpedidos(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_consultanumpedidos() RETURNS TABLE(cantidad bigint)
    LANGUAGE plpgsql
    AS $$
	
	Begin

         return 	QUERY  
				
		select count(*) as cantidad from tbl_pedidos where estatus = 1;
				
	End;
--select * from tbl_recetario
--select * from tbl_materiaprima
--select * from sp_consultahistfinanza()
$$;


ALTER FUNCTION public.sp_consultanumpedidos() OWNER TO postgres;

--
-- Name: sp_consultapedidos(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_consultapedidos(stats integer) RETURNS TABLE(id_pedidos integer, descr character varying, precio_und numeric, total numeric, fecha date, estatus text, cantidad double precision, cliente character varying, usuario character varying, monto double precision)
    LANGUAGE plpgsql
    AS $$
	
	Begin

         return 	QUERY  
				
				SELECT e.id_pedidos, p.descrip, round(e.precio_und::numeric,2),round(e.total::numeric,2), e.fecha, case when e.estatus = 1 then 'PENDIENTE' when e.estatus = 2 then 'PROCESO' else 'COBRANZA' end as status,
				e.cantidad, e.cliente, e.usuario, case when fi.montos is null then 0 else  fi.montos end
				FROM tbl_pedidos e 
				inner join tbl_productos p on p.id_producto = e.id_producto
				left join (select f.id_pedido, sum(f.monto) as montos from tbl_finanzashist f GROUP BY id_pedido) fi on fi.id_pedido = e.id_pedidos
				where e.estatus = stats;
				
				
	End;
--select * from tbl_recetario
--select * from tbl_materiaprima
--select * from tbl_productos
--select * from sp_consultaPedidos(1)
$$;


ALTER FUNCTION public.sp_consultapedidos(stats integer) OWNER TO postgres;

--
-- Name: sp_consultaproducto(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_consultaproducto(idproducto integer) RETURNS TABLE(id_pro integer, descp character varying, precio numeric, ganancia numeric, ctanda double precision)
    LANGUAGE plpgsql
    AS $$
	
	Begin

         return 	QUERY   SELECT e.id_producto, e.descrip,round(e.precio_und::numeric,2),round(e.ganancia::numeric,2), e.ctanda
				FROM tbl_productos e
				where id_producto = idproducto;
	End;
--select * from tbl_productos
--select * from sp_consultaProductos()
--select * from tbl_recetario
$$;


ALTER FUNCTION public.sp_consultaproducto(idproducto integer) OWNER TO postgres;

--
-- Name: sp_consultaproductos(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_consultaproductos() RETURNS TABLE(id_pro integer, descp character varying, precio numeric, ganancia numeric)
    LANGUAGE plpgsql
    AS $$
	
	Begin

         return 	QUERY   SELECT e.id_producto, e.descrip,round(e.precio_und::numeric,2),round(e.ganancia::numeric,2)
				FROM tbl_productos e
				where estatus =1;
	End;
--select * from tbl_productos
--select * from sp_consultaProductos()
--select * from tbl_recetario
$$;


ALTER FUNCTION public.sp_consultaproductos() OWNER TO postgres;

--
-- Name: sp_consultaproductosventas(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_consultaproductosventas() RETURNS TABLE(id_pro integer, descp character varying, precio numeric, ganancia numeric, ctanda double precision)
    LANGUAGE plpgsql
    AS $$
	
	Begin

         return 	QUERY   SELECT e.id_producto, e.descrip,round(e.precio_und::numeric,2),round(e.ganancia::numeric,2), e.ctanda
				FROM tbl_productos e
				inner join (SELECT DISTINCT id_producto FROM tbl_recetario) rec on rec.id_producto  = e.id_producto	
				where estatus =1 and e.precio_und != 0 and e.ganancia != 0;
	End;
--select * from tbl_productos
--select * from sp_consultaProductosventas()
--select * from tbl_recetario
$$;


ALTER FUNCTION public.sp_consultaproductosventas() OWNER TO postgres;

--
-- Name: sp_consultareceta(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_consultareceta(id_product integer) RETURNS TABLE(id_receta integer, id_producto integer, materia_prima character varying, id_mp integer, cantidad numeric)
    LANGUAGE plpgsql
    AS $$
	
	Begin

         return 	QUERY  
				
				SELECT e.id_receta, e.id_producto, m.materiaprima, e.id_materiaprima, round(e.cantidad::numeric,2)
				FROM tbl_recetario e
				inner join tbl_materiaprima m on id = id_materiaprima 
				where e.id_producto = id_product;
				
	End;
--select * from tbl_recetario
--select * from tbl_materiaprima
--select * from sp_consultaReceta(7)
$$;


ALTER FUNCTION public.sp_consultareceta(id_product integer) OWNER TO postgres;

--
-- Name: sp_consultarecetas(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_consultarecetas() RETURNS TABLE(cantidadrec bigint)
    LANGUAGE plpgsql
    AS $$
	
	Begin

         return 	QUERY  
				
		select count(*) as cantidadrec from tbl_recetario;
				
	End;
--select * from tbl_recetario
--select * from tbl_materiaprima
--select * from sp_consultahistfinanza()
$$;


ALTER FUNCTION public.sp_consultarecetas() OWNER TO postgres;

--
-- Name: sp_duplicarreceta(integer, integer, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_duplicarreceta(idproduct integer, idmp integer, cant double precision) RETURNS numeric
    LANGUAGE plpgsql
    AS $$


         	begin
	
				INSERT INTO tbl_recetario(id_producto, id_materiaprima,cantidad)
				VALUES (idproduct, idmp, cant);	
		
		return 1;



End;

$$;


ALTER FUNCTION public.sp_duplicarreceta(idproduct integer, idmp integer, cant double precision) OWNER TO postgres;

--
-- Name: sp_egresocajachica(double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_egresocajachica(egreso double precision) RETURNS numeric
    LANGUAGE plpgsql
    AS $$

  DECLARE Finanza double precision ;

  DECLARE caja double precision ;
          begin
    
    caja:=(SELECT c.total FROM tbl_caja_chica c); 

    if caja <  egreso then return 0; else
    
      Finanza:=(caja - egreso);

      UPDATE tbl_caja_chica
      SET  total=Finanza;

      INSERT INTO tbl_movimiestos_caja_chica( tipo_movimiento, cantidad, usuario)
      VALUES (2, egreso, '');


      return 1;
    end if;
    
  
    

End;

$$;


ALTER FUNCTION public.sp_egresocajachica(egreso double precision) OWNER TO postgres;

--
-- Name: sp_eliminararticulo(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_eliminararticulo(idmp integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
	
	
         	begin
		DELETE FROM tbl_materiaprima
		WHERE id = idmp;

		DELETE FROM tbl_inventario
		WHERE id_materiaprima = idmp;

		return 1;

End;

$$;


ALTER FUNCTION public.sp_eliminararticulo(idmp integer) OWNER TO postgres;

--
-- Name: sp_eliminarpedido(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_eliminarpedido(idpedido integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
	
	declare validacionPago int;
         	begin
		validacionPago := (select count(*) from tbl_finanzashist where id_pedido = idpedido);
		if (validacionPago = 1) then
		DELETE FROM tbl_finanzashist
		WHERE id_pedido = idpedido;
		end if;
		DELETE FROM tbl_pedidos
		WHERE id_pedidos = idpedido;

		return 1;

End;

$$;


ALTER FUNCTION public.sp_eliminarpedido(idpedido integer) OWNER TO postgres;

--
-- Name: sp_guardarcajachica(double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_guardarcajachica(monto double precision) RETURNS numeric
    LANGUAGE plpgsql
    AS $$

  DECLARE Finanza double precision ;
  DECLARE total double precision;
  DECLARE caja double precision;
          begin
    -- select * from sp_guardarcajachica(10)
    Finanza:=(SELECT f.capital FROM tbl_finanzas f);
    caja:=(SELECT cc.total FROM tbl_caja_chica cc); 

    if Finanza <  monto then return 0; else
    
      total:=(Finanza - monto);

      UPDATE tbl_caja_chica
      SET  total=(monto+caja);

      INSERT INTO tbl_movimiestos_caja_chica( tipo_movimiento, cantidad, usuario)
      VALUES (1, monto, '');


      INSERT INTO tbl_finanzashist(monto, tipo_tx, fecha, concepto)
      VALUES (monto, 2, now(), 'MOVIMIENTO A CAJA CHICA');

      UPDATE tbl_finanzas
      SET capital=(total);

      return 1;
    end if;
    
  
    

End;

$$;


ALTER FUNCTION public.sp_guardarcajachica(monto double precision) OWNER TO postgres;

--
-- Name: sp_listamp(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_listamp() RETURNS TABLE(id_mp integer, descp character varying, usuario character varying)
    LANGUAGE plpgsql
    AS $$
	
	Begin

         return 	QUERY   SELECT *  FROM tbl_materiaprima;
	End;

$$;


ALTER FUNCTION public.sp_listamp() OWNER TO postgres;

--
-- Name: sp_listampprecio(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_listampprecio() RETURNS TABLE(id_mp integer, descp character varying, usuario character varying, precio_materiaprima double precision)
    LANGUAGE plpgsql
    AS $$
	
	Begin

         return 	QUERY   SELECT *  FROM tbl_materiaprima mp where mp.precio_materiaprima IS NOT NULL;
	End;

$$;


ALTER FUNCTION public.sp_listampprecio() OWNER TO postgres;

--
-- Name: sp_modifgastoef(integer, date, double precision, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_modifgastoef(egresofijo integer, fechacompra date, precionuevo double precision, idcompra integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
	--select * from sp_nuevoModifGastoMP ('1', '1/1/2021', '1', '100', '200','001', '6');
	DECLARE precioanterior double precision;

         	begin
		precioanterior:=(select c.precio from tbl_compras c WHERE id_compra=idcompra);	--ubicando precio anterior en compra a editar compra
	

		UPDATE tbl_compras 
		   SET  fecha_compra=fechacompra, fecha_creacion=now(), precio=precionuevo, id_egresofijo=egresofijo
		 WHERE id_compra=idcompra;


		UPDATE tbl_finanzashist
		   SET monto=precionuevo, fecha=now()
		 WHERE id_compra=idcompra;
		
		UPDATE tbl_finanzas
		SET capital=(capital + precioanterior - precionuevo);

		return 1;

		--select * from tbl_compras
		--select * from tbl_finanzas
		--select * from tbl_finanzashist


End;

$$;


ALTER FUNCTION public.sp_modifgastoef(egresofijo integer, fechacompra date, precionuevo double precision, idcompra integer) OWNER TO postgres;

--
-- Name: sp_modificararticulo(character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_modificararticulo(materiap character varying, idmp integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
	
	DECLARE existe integer;
         	begin
		existe:= (select count(*) from tbl_materiaprima where upper(materiaprima) = materiap); --Validando si existe el nuevo producto
		if existe = 0 then -- si no existe, insert
		UPDATE tbl_materiaprima
		SET materiaprima=materiap
		WHERE id=idmp;

		return 1;
		else return 0; 
		end if;
--select * from  sp_nuevoarticulo('HARINA','1')
--select * from tbl_materiaprima
		


End;

$$;


ALTER FUNCTION public.sp_modificararticulo(materiap character varying, idmp integer) OWNER TO postgres;

--
-- Name: sp_modificaregresofijo(character varying, double precision, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_modificaregresofijo(ef character varying, gasto double precision, id character varying) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
	
         	begin
		UPDATE tbl_egresosfijos
		SET egresofijo=ef, costo=gasto, fechacrea=now(), usuariocrea=''
		WHERE id_egresofijo=id::integer;

		return 1;


End;

$$;


ALTER FUNCTION public.sp_modificaregresofijo(ef character varying, gasto double precision, id character varying) OWNER TO postgres;

--
-- Name: sp_modifpedido(integer, double precision, double precision, double precision, character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_modifpedido(producto integer, precio double precision, cant double precision, costo double precision, pago character varying, client character varying, idpedido integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
	declare pagoanterior double precision;
	declare consultapagoanterior character varying;
	declare montosinpagoanterior double precision;
	Begin
--select * from sp_modifPedido('1','11','2','22','11','Josef','20')
--validando si pago llega vacio, setear 0
				pago = (case when pago != '' then  pago else '0' end);
				if (pago::double precision <= costo) then
					consultapagoanterior:=(select monto from tbl_finanzashist where id_pedido = idpedido); --capturando pago anterior
					pagoanterior = (case when  consultapagoanterior is null or consultapagoanterior = '' then 0 else consultapagoanterior::double precision end);
					--Validando que no sea 0, en caso afirmativo borrando registro de historico de pagos.
					if (pago::double precision = 0) then
						DELETE FROM tbl_finanzashist WHERE id_pedido = idpedido;
						UPDATE tbl_finanzas
						SET capital=(capital - pagoanterior);
					else
						UPDATE tbl_finanzashist
						SET monto=pago::double precision
						WHERE id_pedido = idpedido;

						
						UPDATE tbl_finanzas
						SET capital=(capital + pago::double precision - pagoanterior);
					end if;
					
					--actualizar pedido
					UPDATE tbl_pedidos
					   SET id_producto=producto, precio_und=precio, total=costo, cantidad=cantidad, cliente=client
					 WHERE id_pedidos = idpedido;
					 return 1;
				 else return 0;
				end if;

		

	End;
--delete from tbl_pedidos
--select * from tbl_finanzashist
$$;


ALTER FUNCTION public.sp_modifpedido(producto integer, precio double precision, cant double precision, costo double precision, pago character varying, client character varying, idpedido integer) OWNER TO postgres;

--
-- Name: sp_movimientos_caja_chica(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_movimientos_caja_chica() RETURNS TABLE(id_out integer, nombre_out character varying, cantidad_out double precision, usuario_out character varying, fecha_registro_out date)
    LANGUAGE plpgsql
    AS $$

Begin

        return QUERY  

SELECT m.id, t.nombre ,m.cantidad, m.usuario, m.fecha_registro
FROM tbl_movimiestos_caja_chica m
INNER JOIN tbl_tipo_movimientos t ON t.id_movimiento = m.tipo_movimiento;



End;

$$;


ALTER FUNCTION public.sp_movimientos_caja_chica() OWNER TO postgres;

--
-- Name: sp_nuevareceta(integer, integer, double precision, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_nuevareceta(idproduct integer, idmp integer, cant double precision, indexx integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$

	DECLARE existe integer;
		cantmp integer;
		idrecetaanterior integer;
         	begin
		existe:= (select count(*) from tbl_recetario where id_materiaprima = idmp and id_producto=idproduct); --Validando si existe el nuevo producto
		if existe = 0 then -- si no existe, insert
			cantmp:= (select count(*) from tbl_recetario where id_producto=idproduct);
			if(indexx <= cantmp) then
				indexx=indexx-1;
				idrecetaanterior:=(select id_receta from tbl_recetario where id_producto=idproduct  order by id_receta asc limit 1 offset indexx );
				
				
				UPDATE tbl_recetario
				SET id_producto=idproduct, id_materiaprima=idmp, 
				cantidad=cant
				where id_receta = idrecetaanterior;
			else
				INSERT INTO tbl_recetario(id_producto, id_materiaprima,cantidad)
				VALUES (idproduct, idmp, cant);	
			end if;
		else 
			UPDATE tbl_recetario
			SET id_producto=idproduct, id_materiaprima=idmp, 
			cantidad=cant
			where id_materiaprima = idmp and id_producto=idproduct;
		end if;
		return 1;
--select * from  sp_nuevaReceta(3,12,100,2)
		--select * from tbl_recetario where id_producto=3 


End;

$$;


ALTER FUNCTION public.sp_nuevareceta(idproduct integer, idmp integer, cant double precision, indexx integer) OWNER TO postgres;

--
-- Name: sp_nuevoarticulo(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_nuevoarticulo(materiap character varying) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
	
	DECLARE existe integer;
	DECLARE idmp integer;
         	begin
		existe:= (select count(*) from tbl_materiaprima where upper(materiaprima) = materiap); --Validando si existe el nuevo producto
		if existe = 0 then -- si no existe, insert
		INSERT INTO tbl_materiaprima(materiaprima, usuario)
		VALUES (materiap, '');
		idmp:=(select max(id) from tbl_materiaprima);
		INSERT INTO tbl_inventario(
		cant_stock, id_materiaprima)
		VALUES (0, idmp);

		return 1;
		
		else return 0; 
		end if;
--select * from  sp_nuevoarticulo('HARINA')
		


End;

$$;


ALTER FUNCTION public.sp_nuevoarticulo(materiap character varying) OWNER TO postgres;

--
-- Name: sp_nuevoegresofijo(character varying, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_nuevoegresofijo(ef character varying, gasto double precision) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
	
         	begin
	INSERT INTO tbl_egresosfijos(
             egresofijo, costo, fechacrea, usuariocrea)
    VALUES ( EF, gasto, now(), '');
		return 1;


End;

$$;


ALTER FUNCTION public.sp_nuevoegresofijo(ef character varying, gasto double precision) OWNER TO postgres;

--
-- Name: sp_nuevogastoef(integer, date, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_nuevogastoef(egresofijo integer, fechacompra date, gasto double precision) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
	--select * from sp_nuevoGastoMP ('1', '001', '1/1/2021', '1', '100', '200');
	DECLARE idcompra integer;
         	begin
		INSERT INTO tbl_compras(
		 fecha_compra,usuario, fecha_creacion, precio,id_egresofijo)
		VALUES (fechacompra,'',now(),gasto,egresofijo);

		idcompra:=(select max(id_compra) from tbl_compras);	--ubicando ultimo id compra

		INSERT INTO tbl_finanzashist(
			monto, tipo_tx, fecha, id_compra)
		VALUES (gasto, 2, now(), idcompra);

		UPDATE tbl_finanzas
		SET capital=(capital - gasto);
	
		return 1;

		--select * from tbl_compras
		--select * from tbl_finanzas
		--select * from tbl_finanzashist
		--select * from tbl_inventario


End;

$$;


ALTER FUNCTION public.sp_nuevogastoef(egresofijo integer, fechacompra date, gasto double precision) OWNER TO postgres;

--
-- Name: sp_nuevogastomp(integer, date, double precision, double precision, double precision, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_nuevogastomp(materiap integer, fechacompra date, cant double precision, precio double precision, pesomp double precision, numcompra integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
	--select * from sp_nuevoGastoMP ('1', '001', '1/1/2021', '1', '100', '200');
	DECLARE idcompra integer;
         	begin
		INSERT INTO tbl_compras(
		id_materiaprima, nro_compra, fecha_compra, cantidad_mp, 
		usuario, fecha_creacion, precio, peso)
		VALUES (materiap, numcompra, fechacompra,cant, '', 
		now(), precio, pesomp);

		idcompra:=(select max(id_compra) from tbl_compras);	--ubicando ultimo id compra

		INSERT INTO tbl_finanzashist(
			monto, tipo_tx, fecha, id_compra)
		VALUES (precio, 2, now(), idcompra);
		
		UPDATE tbl_inventario
		   SET cant_stock=(cant_stock + (cant * pesomp))
		 WHERE id_materiaprima = materiap;

		update tbl_materiaprima
			set precio_materiaprima = ( precio / pesomp )
		WHERE id = materiap;

		UPDATE tbl_finanzas
		SET capital=(capital - (cant * precio));
	
		return 1;

		--select * from tbl_compras
		--select * from tbl_finanzas
		--select * from tbl_finanzashist
		--select * from tbl_inventario


End;

$$;


ALTER FUNCTION public.sp_nuevogastomp(materiap integer, fechacompra date, cant double precision, precio double precision, pesomp double precision, numcompra integer) OWNER TO postgres;

--
-- Name: sp_nuevomodifgastomp(integer, date, double precision, double precision, double precision, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_nuevomodifgastomp(materiap integer, fechacompra date, cant double precision, precionuevo double precision, pesomp double precision, numcompra integer, idcompra integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
	--select * from sp_nuevoModifGastoMP ('1', '1/1/2021', '1', '100', '200','001', '6');
	DECLARE precioanterior double precision;
	DECLARE cantanterior double precision;
	DECLARE pesoanterior double precision;
         	begin
		precioanterior:=(select c.precio from tbl_compras c WHERE id_compra=idcompra);	--ubicando precio anterior en compra a editar compra
		cantanterior:=(select c.cantidad_mp from tbl_compras c WHERE id_compra=idcompra);	--ubicando precio anterior en compra a editar compra
		pesoanterior:=(select c.peso from tbl_compras c WHERE id_compra=idcompra);	--ubicando precio anterior en compra a editar compra

		UPDATE tbl_compras 
		   SET  id_materiaprima=materiap, nro_compra=numcompra, fecha_compra=fechacompra, 
		       cantidad_mp=cant, fecha_creacion=now(), precio=precionuevo, peso=pesomp 
		 WHERE id_compra=idcompra;

		update tbl_materiaprima
			set precio_materiaprima = ( precionuevo / pesomp )
		WHERE id = materiap; 

		UPDATE tbl_finanzashist
		   SET monto=precionuevo, fecha=now()
		 WHERE id_compra=idcompra;
		
		UPDATE tbl_inventario
		   SET cant_stock=(cant_stock - (cantanterior * pesoanterior) + (cant * pesomp))
		 WHERE id_materiaprima = materiap;
		UPDATE tbl_finanzas
		SET capital=(capital + precioanterior - precionuevo);

		return 1;

		--select * from tbl_compras
		--select * from tbl_finanzas
		--select * from tbl_finanzashist


End;

$$;


ALTER FUNCTION public.sp_nuevomodifgastomp(materiap integer, fechacompra date, cant double precision, precionuevo double precision, pesomp double precision, numcompra integer, idcompra integer) OWNER TO postgres;

--
-- Name: sp_nuevopago(integer, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_nuevopago(idpedido integer, nuevopago double precision, deuda double precision) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
	Begin
				if nuevopago > deuda then --El pago no puede ser mayor a la deuda, retorna 0
				return 0;
				else
					if nuevopago = deuda then --el pago es igual a la deduda actual el pedido pasa a estatus COMPLETADO (4)
						UPDATE tbl_pedidos
						SET  estatus=4
						WHERE id_pedidos=idpedido;
					end if;

					INSERT INTO tbl_finanzashist(
						monto, tipo_tx, fecha, id_pedido)
					VALUES (nuevopago, 1, now(), idpedido);


					UPDATE tbl_finanzas
					SET capital=(capital + nuevopago);
 

					return 1;
				end if;
		

	End;
--select * from tbl_pedidos
--select * from tbl_finanzashist
$$;


ALTER FUNCTION public.sp_nuevopago(idpedido integer, nuevopago double precision, deuda double precision) OWNER TO postgres;

--
-- Name: sp_nuevopedido(integer, double precision, double precision, double precision, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_nuevopedido(producto integer, precio double precision, cantidad double precision, costo double precision, pago character varying, client character varying) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
	declare idpedido integer;
	Begin
--select * from sp_nuevoPedido('5','11','2','22','21','Josef')
--select * from tbl_pedidos
			--validando si pago llega vacio, setear 0
			pago = (case when pago != '' then  pago else '0' end);
			if (pago::double precision <= costo) then
				INSERT INTO tbl_pedidos(
					    id_producto, precio_und, total, fecha,  estatus, 
					    cantidad, cliente)
				    VALUES (producto, precio, costo, now(), 1, cantidad, client);

				--Validando si hubo un pago previo
				
				idpedido:=(select max(id_pedidos) from tbl_pedidos);
				INSERT INTO tbl_finanzashist(
					     monto, tipo_tx, fecha, id_pedido)
				    VALUES (pago::double precision, 1, now(), idpedido);

				if pago != '0' then
				UPDATE tbl_finanzas
					SET capital=(capital + pago::double precision);

				end if;
				return 1;

			else return 0;
			end if;
		

	End;
--select * from tbl_pedidos
--select * from tbl_finanzashist
$$;


ALTER FUNCTION public.sp_nuevopedido(producto integer, precio double precision, cantidad double precision, costo double precision, pago character varying, client character varying) OWNER TO postgres;

--
-- Name: sp_nuevoproducto(character varying, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_nuevoproducto(product character varying, prec double precision, cantidadtanda double precision) RETURNS numeric
    LANGUAGE plpgsql
    AS $$

	DECLARE existe integer;
         	begin
		existe:= (select count(*) from tbl_productos where upper(descrip) = product); --Validando si existe el nuevo producto
		if existe = 0 then -- si no existe, insert
		INSERT INTO tbl_productos(descrip, estatus,precio_und,ganancia,ctanda)
		VALUES (product, 1, prec,prec,cantidadtanda);
		return 1;
		else return 0; 
		end if;
--select * from  sp_nuevoarticulo('HARINA')
		


End;

$$;


ALTER FUNCTION public.sp_nuevoproducto(product character varying, prec double precision, cantidadtanda double precision) OWNER TO postgres;

--
-- Name: sp_nuevoproductoduplicado(character varying, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_nuevoproductoduplicado(product character varying, prec double precision, cantidadtanda double precision) RETURNS numeric
    LANGUAGE plpgsql
    AS $$

	DECLARE existe integer;
         	begin
		existe:= (select count(*) from tbl_productos where upper(descrip) = product); --Validando si existe el nuevo producto
		if existe = 0 then -- si no existe, insert
		INSERT INTO tbl_productos(descrip, estatus,precio_und,ganancia, ctanda)
		VALUES (product, 1, prec,prec, cantidadtanda);
		return (select max(id_producto) from tbl_productos);
		else return 0; 
		end if;
--select * from  sp_nuevoarticulo('HARINA')
		


End;

$$;


ALTER FUNCTION public.sp_nuevoproductoduplicado(product character varying, prec double precision, cantidadtanda double precision) OWNER TO postgres;

--
-- Name: sp_receta(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_receta(idproduct integer) RETURNS TABLE(descrip character varying, materiaprima character varying, cantidad double precision, idmp integer)
    LANGUAGE plpgsql
    AS $$
	
	Begin 

         return 	QUERY   select p.descrip, m.materiaprima, r.cantidad, r.id_materiaprima from tbl_recetario r 
				inner join tbl_materiaprima m on r.id_materiaprima = m.id
				inner join tbl_productos p on p.id_producto = r.id_producto
				where r.id_producto=idproduct;

	End;

$$;


ALTER FUNCTION public.sp_receta(idproduct integer) OWNER TO postgres;

--
-- Name: sp_total_caja_chica(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sp_total_caja_chica() RETURNS TABLE(id_out integer, total_out numeric)
    LANGUAGE plpgsql
    AS $$
	
	Begin

         return 	QUERY  
				
				SELECT id, round(total::numeric, 2)
					FROM tbl_caja_chica LIMIT 1;	

				
				
	End;

$$;


ALTER FUNCTION public.sp_total_caja_chica() OWNER TO postgres;

--
-- Name: caja_chica_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.caja_chica_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.caja_chica_id_seq OWNER TO postgres;

--
-- Name: movimiestos_caja_chica_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.movimiestos_caja_chica_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.movimiestos_caja_chica_id_seq OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tbl_caja_chica; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.tbl_caja_chica (
    id integer DEFAULT nextval('public.caja_chica_id_seq'::regclass) NOT NULL,
    total double precision NOT NULL
);


ALTER TABLE public.tbl_caja_chica OWNER TO postgres;

--
-- Name: tbl_compras; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.tbl_compras (
    id_compra integer NOT NULL,
    id_materiaprima integer,
    nro_compra character varying,
    fecha_compra date,
    usuario character varying,
    fecha_creacion date,
    precio double precision,
    id_egresofijo integer,
    cantidad_mp double precision,
    peso double precision
);


ALTER TABLE public.tbl_compras OWNER TO postgres;

--
-- Name: tbl_compras_id_compra_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_compras_id_compra_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_compras_id_compra_seq OWNER TO postgres;

--
-- Name: tbl_compras_id_compra_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tbl_compras_id_compra_seq OWNED BY public.tbl_compras.id_compra;


--
-- Name: tbl_egresosfijos; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.tbl_egresosfijos (
    id_egresofijo integer NOT NULL,
    egresofijo character varying NOT NULL,
    costo double precision,
    fechacrea date,
    usuariocrea character varying
);


ALTER TABLE public.tbl_egresosfijos OWNER TO postgres;

--
-- Name: tbl_egresosfijos_id_egresofijo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_egresosfijos_id_egresofijo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_egresosfijos_id_egresofijo_seq OWNER TO postgres;

--
-- Name: tbl_egresosfijos_id_egresofijo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tbl_egresosfijos_id_egresofijo_seq OWNED BY public.tbl_egresosfijos.id_egresofijo;


--
-- Name: tbl_estatuspedidos; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.tbl_estatuspedidos (
    id_estatuspedido integer NOT NULL,
    estatuspedido character varying
);


ALTER TABLE public.tbl_estatuspedidos OWNER TO postgres;

--
-- Name: tbl_estatuspedidos_id_estatuspedido_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_estatuspedidos_id_estatuspedido_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_estatuspedidos_id_estatuspedido_seq OWNER TO postgres;

--
-- Name: tbl_estatuspedidos_id_estatuspedido_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tbl_estatuspedidos_id_estatuspedido_seq OWNED BY public.tbl_estatuspedidos.id_estatuspedido;


--
-- Name: tbl_finanzas; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.tbl_finanzas (
    id_finanzas integer NOT NULL,
    capital double precision
);


ALTER TABLE public.tbl_finanzas OWNER TO postgres;

--
-- Name: tbl_finanzas_id_finanzas_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_finanzas_id_finanzas_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_finanzas_id_finanzas_seq OWNER TO postgres;

--
-- Name: tbl_finanzas_id_finanzas_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tbl_finanzas_id_finanzas_seq OWNED BY public.tbl_finanzas.id_finanzas;


--
-- Name: tbl_finanzashist; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.tbl_finanzashist (
    id_finanzahist integer NOT NULL,
    monto double precision,
    tipo_tx integer,
    concepto character varying,
    fecha date,
    usuario character varying,
    id_pedido integer,
    id_compra integer
);


ALTER TABLE public.tbl_finanzashist OWNER TO postgres;

--
-- Name: tbl_finanzashist_id_finanzahist_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_finanzashist_id_finanzahist_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_finanzashist_id_finanzahist_seq OWNER TO postgres;

--
-- Name: tbl_finanzashist_id_finanzahist_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tbl_finanzashist_id_finanzahist_seq OWNED BY public.tbl_finanzashist.id_finanzahist;


--
-- Name: tbl_inventario; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.tbl_inventario (
    id integer NOT NULL,
    cant_stock double precision,
    id_materiaprima integer
);


ALTER TABLE public.tbl_inventario OWNER TO postgres;

--
-- Name: tbl_inventario_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_inventario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_inventario_id_seq OWNER TO postgres;

--
-- Name: tbl_inventario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tbl_inventario_id_seq OWNED BY public.tbl_inventario.id;


--
-- Name: tbl_materiaprima; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.tbl_materiaprima (
    id integer NOT NULL,
    materiaprima character varying(70),
    usuario character varying(70),
    precio_materiaprima double precision
);


ALTER TABLE public.tbl_materiaprima OWNER TO postgres;

--
-- Name: tbl_materiaprima_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_materiaprima_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_materiaprima_id_seq OWNER TO postgres;

--
-- Name: tbl_materiaprima_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tbl_materiaprima_id_seq OWNED BY public.tbl_materiaprima.id;


--
-- Name: tbl_movimiestos_caja_chica; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.tbl_movimiestos_caja_chica (
    id integer DEFAULT nextval('public.movimiestos_caja_chica_id_seq'::regclass) NOT NULL,
    tipo_movimiento integer NOT NULL,
    cantidad double precision NOT NULL,
    usuario character varying(50),
    fecha_registro date DEFAULT now() NOT NULL
);


ALTER TABLE public.tbl_movimiestos_caja_chica OWNER TO postgres;

--
-- Name: tbl_pedidos; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.tbl_pedidos (
    id_pedidos integer NOT NULL,
    id_producto integer,
    precio_und double precision,
    total double precision,
    fecha date,
    usuario character varying,
    estatus integer,
    cantidad double precision,
    cliente character varying
);


ALTER TABLE public.tbl_pedidos OWNER TO postgres;

--
-- Name: tbl_pedidos_id_pedidos_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_pedidos_id_pedidos_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_pedidos_id_pedidos_seq OWNER TO postgres;

--
-- Name: tbl_pedidos_id_pedidos_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tbl_pedidos_id_pedidos_seq OWNED BY public.tbl_pedidos.id_pedidos;


--
-- Name: tbl_productos; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.tbl_productos (
    id_producto integer NOT NULL,
    descrip character varying,
    estatus integer,
    precio_und double precision,
    ganancia double precision,
    ctanda double precision
);


ALTER TABLE public.tbl_productos OWNER TO postgres;

--
-- Name: tbl_productos_id_producto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_productos_id_producto_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_productos_id_producto_seq OWNER TO postgres;

--
-- Name: tbl_productos_id_producto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tbl_productos_id_producto_seq OWNED BY public.tbl_productos.id_producto;


--
-- Name: tbl_recetario; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.tbl_recetario (
    id_receta integer NOT NULL,
    id_producto integer,
    materia_prima character varying,
    id_materiaprima integer,
    cantidad double precision
);


ALTER TABLE public.tbl_recetario OWNER TO postgres;

--
-- Name: tbl_recetario_id_receta_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_recetario_id_receta_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_recetario_id_receta_seq OWNER TO postgres;

--
-- Name: tbl_recetario_id_receta_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tbl_recetario_id_receta_seq OWNED BY public.tbl_recetario.id_receta;


--
-- Name: tbl_tipo_movimientos; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.tbl_tipo_movimientos (
    id_movimiento integer NOT NULL,
    nombre character varying(50) NOT NULL
);


ALTER TABLE public.tbl_tipo_movimientos OWNER TO postgres;

--
-- Name: tbl_tipo_movimientos_id_movimiento_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_tipo_movimientos_id_movimiento_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_tipo_movimientos_id_movimiento_seq OWNER TO postgres;

--
-- Name: tbl_tipo_movimientos_id_movimiento_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tbl_tipo_movimientos_id_movimiento_seq OWNED BY public.tbl_tipo_movimientos.id_movimiento;


--
-- Name: id_compra; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_compras ALTER COLUMN id_compra SET DEFAULT nextval('public.tbl_compras_id_compra_seq'::regclass);


--
-- Name: id_egresofijo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_egresosfijos ALTER COLUMN id_egresofijo SET DEFAULT nextval('public.tbl_egresosfijos_id_egresofijo_seq'::regclass);


--
-- Name: id_estatuspedido; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_estatuspedidos ALTER COLUMN id_estatuspedido SET DEFAULT nextval('public.tbl_estatuspedidos_id_estatuspedido_seq'::regclass);


--
-- Name: id_finanzas; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_finanzas ALTER COLUMN id_finanzas SET DEFAULT nextval('public.tbl_finanzas_id_finanzas_seq'::regclass);


--
-- Name: id_finanzahist; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_finanzashist ALTER COLUMN id_finanzahist SET DEFAULT nextval('public.tbl_finanzashist_id_finanzahist_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_inventario ALTER COLUMN id SET DEFAULT nextval('public.tbl_inventario_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_materiaprima ALTER COLUMN id SET DEFAULT nextval('public.tbl_materiaprima_id_seq'::regclass);


--
-- Name: id_pedidos; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_pedidos ALTER COLUMN id_pedidos SET DEFAULT nextval('public.tbl_pedidos_id_pedidos_seq'::regclass);


--
-- Name: id_producto; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_productos ALTER COLUMN id_producto SET DEFAULT nextval('public.tbl_productos_id_producto_seq'::regclass);


--
-- Name: id_receta; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_recetario ALTER COLUMN id_receta SET DEFAULT nextval('public.tbl_recetario_id_receta_seq'::regclass);


--
-- Name: id_movimiento; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_tipo_movimientos ALTER COLUMN id_movimiento SET DEFAULT nextval('public.tbl_tipo_movimientos_id_movimiento_seq'::regclass);


--
-- Name: caja_chica_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.caja_chica_id_seq', 2, true);


--
-- Name: movimiestos_caja_chica_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.movimiestos_caja_chica_id_seq', 29, true);


--
-- Data for Name: tbl_caja_chica; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_caja_chica (id, total) FROM stdin;
\.
COPY public.tbl_caja_chica (id, total) FROM '$$PATH$$/2159.dat';

--
-- Data for Name: tbl_compras; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_compras (id_compra, id_materiaprima, nro_compra, fecha_compra, usuario, fecha_creacion, precio, id_egresofijo, cantidad_mp, peso) FROM stdin;
\.
COPY public.tbl_compras (id_compra, id_materiaprima, nro_compra, fecha_compra, usuario, fecha_creacion, precio, id_egresofijo, cantidad_mp, peso) FROM '$$PATH$$/2160.dat';

--
-- Name: tbl_compras_id_compra_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_compras_id_compra_seq', 47, true);


--
-- Data for Name: tbl_egresosfijos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_egresosfijos (id_egresofijo, egresofijo, costo, fechacrea, usuariocrea) FROM stdin;
\.
COPY public.tbl_egresosfijos (id_egresofijo, egresofijo, costo, fechacrea, usuariocrea) FROM '$$PATH$$/2162.dat';

--
-- Name: tbl_egresosfijos_id_egresofijo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_egresosfijos_id_egresofijo_seq', 8, true);


--
-- Data for Name: tbl_estatuspedidos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_estatuspedidos (id_estatuspedido, estatuspedido) FROM stdin;
\.
COPY public.tbl_estatuspedidos (id_estatuspedido, estatuspedido) FROM '$$PATH$$/2164.dat';

--
-- Name: tbl_estatuspedidos_id_estatuspedido_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_estatuspedidos_id_estatuspedido_seq', 1, false);


--
-- Data for Name: tbl_finanzas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_finanzas (id_finanzas, capital) FROM stdin;
\.
COPY public.tbl_finanzas (id_finanzas, capital) FROM '$$PATH$$/2166.dat';

--
-- Name: tbl_finanzas_id_finanzas_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_finanzas_id_finanzas_seq', 1, true);


--
-- Data for Name: tbl_finanzashist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_finanzashist (id_finanzahist, monto, tipo_tx, concepto, fecha, usuario, id_pedido, id_compra) FROM stdin;
\.
COPY public.tbl_finanzashist (id_finanzahist, monto, tipo_tx, concepto, fecha, usuario, id_pedido, id_compra) FROM '$$PATH$$/2168.dat';

--
-- Name: tbl_finanzashist_id_finanzahist_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_finanzashist_id_finanzahist_seq', 113, true);


--
-- Data for Name: tbl_inventario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_inventario (id, cant_stock, id_materiaprima) FROM stdin;
\.
COPY public.tbl_inventario (id, cant_stock, id_materiaprima) FROM '$$PATH$$/2170.dat';

--
-- Name: tbl_inventario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_inventario_id_seq', 38, true);


--
-- Data for Name: tbl_materiaprima; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_materiaprima (id, materiaprima, usuario, precio_materiaprima) FROM stdin;
\.
COPY public.tbl_materiaprima (id, materiaprima, usuario, precio_materiaprima) FROM '$$PATH$$/2172.dat';

--
-- Name: tbl_materiaprima_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_materiaprima_id_seq', 48, true);


--
-- Data for Name: tbl_movimiestos_caja_chica; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_movimiestos_caja_chica (id, tipo_movimiento, cantidad, usuario, fecha_registro) FROM stdin;
\.
COPY public.tbl_movimiestos_caja_chica (id, tipo_movimiento, cantidad, usuario, fecha_registro) FROM '$$PATH$$/2174.dat';

--
-- Data for Name: tbl_pedidos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_pedidos (id_pedidos, id_producto, precio_und, total, fecha, usuario, estatus, cantidad, cliente) FROM stdin;
\.
COPY public.tbl_pedidos (id_pedidos, id_producto, precio_und, total, fecha, usuario, estatus, cantidad, cliente) FROM '$$PATH$$/2175.dat';

--
-- Name: tbl_pedidos_id_pedidos_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_pedidos_id_pedidos_seq', 53, true);


--
-- Data for Name: tbl_productos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_productos (id_producto, descrip, estatus, precio_und, ganancia, ctanda) FROM stdin;
\.
COPY public.tbl_productos (id_producto, descrip, estatus, precio_und, ganancia, ctanda) FROM '$$PATH$$/2177.dat';

--
-- Name: tbl_productos_id_producto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_productos_id_producto_seq', 46, true);


--
-- Data for Name: tbl_recetario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_recetario (id_receta, id_producto, materia_prima, id_materiaprima, cantidad) FROM stdin;
\.
COPY public.tbl_recetario (id_receta, id_producto, materia_prima, id_materiaprima, cantidad) FROM '$$PATH$$/2179.dat';

--
-- Name: tbl_recetario_id_receta_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_recetario_id_receta_seq', 140, true);


--
-- Data for Name: tbl_tipo_movimientos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_tipo_movimientos (id_movimiento, nombre) FROM stdin;
\.
COPY public.tbl_tipo_movimientos (id_movimiento, nombre) FROM '$$PATH$$/2181.dat';

--
-- Name: tbl_tipo_movimientos_id_movimiento_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_tipo_movimientos_id_movimiento_seq', 2, true);


--
-- Name: egresofijo_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.tbl_egresosfijos
    ADD CONSTRAINT egresofijo_pk PRIMARY KEY (egresofijo);


--
-- Name: id_compra_primarykey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.tbl_compras
    ADD CONSTRAINT id_compra_primarykey PRIMARY KEY (id_compra);


--
-- Name: pk_idestatuspedido; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.tbl_estatuspedidos
    ADD CONSTRAINT pk_idestatuspedido PRIMARY KEY (id_estatuspedido);


--
-- Name: pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.tbl_pedidos
    ADD CONSTRAINT pkey PRIMARY KEY (id_pedidos);


--
-- Name: pkey_tblrecetario; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.tbl_recetario
    ADD CONSTRAINT pkey_tblrecetario PRIMARY KEY (id_receta);


--
-- Name: primarykey_idMateriaPrima; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.tbl_materiaprima
    ADD CONSTRAINT "primarykey_idMateriaPrima" PRIMARY KEY (id);


--
-- Name: primarykey_idinventario; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.tbl_inventario
    ADD CONSTRAINT primarykey_idinventario PRIMARY KEY (id);


--
-- Name: primarykey_tbl_finanzasHist; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.tbl_finanzashist
    ADD CONSTRAINT "primarykey_tbl_finanzasHist" PRIMARY KEY (id_finanzahist);


--
-- Name: primarykey_tblfinanzas; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.tbl_finanzas
    ADD CONSTRAINT primarykey_tblfinanzas PRIMARY KEY (id_finanzas);


--
-- Name: primerkey_tblproducto; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.tbl_productos
    ADD CONSTRAINT primerkey_tblproducto PRIMARY KEY (id_producto);


--
-- Name: tbl_caja_chica_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.tbl_caja_chica
    ADD CONSTRAINT tbl_caja_chica_pkey PRIMARY KEY (id);


--
-- Name: tbl_movimiestos_caja_chica_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.tbl_movimiestos_caja_chica
    ADD CONSTRAINT tbl_movimiestos_caja_chica_pkey PRIMARY KEY (id);


--
-- Name: tbl_tipo_movimientos_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.tbl_tipo_movimientos
    ADD CONSTRAINT tbl_tipo_movimientos_nombre_key UNIQUE (nombre);


--
-- Name: tbl_tipo_movimientos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.tbl_tipo_movimientos
    ADD CONSTRAINT tbl_tipo_movimientos_pkey PRIMARY KEY (id_movimiento);


--
-- Name: tbl_movimiestos_caja_chica_tipo_movimiento_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_movimiestos_caja_chica
    ADD CONSTRAINT tbl_movimiestos_caja_chica_tipo_movimiento_fkey FOREIGN KEY (tipo_movimiento) REFERENCES public.tbl_tipo_movimientos(id_movimiento);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

